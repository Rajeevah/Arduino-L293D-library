
#include <Arduino.h> 
#include <L293D.h>


void L293D::moveBackward()
{
	digitalWrite(m1pinS, LOW);
	analogWrite(m1pinN, pwm);
	
	digitalWrite(m2pinN, LOW);	
	analogWrite(m2pinS,pwm );     
	delay(1000);  
	
}

void L293D::moveForward()
{
	digitalWrite(m1pinN, LOW);
	analogWrite(m1pinS, pwm);
	
	digitalWrite(m2pinS, LOW);	
	analogWrite(m2pinN,pwm );  
	delay(1000); 
  
}

void L293D::fwdRight()
{
	digitalWrite(m1pinN, LOW);
	analogWrite(m1pinS, turnPwm);
	
	digitalWrite(m2pinS, LOW);	
	analogWrite(m2pinN,pwm );
	delay(1000);  
}

void L293D::fwdLeft()
{

	digitalWrite(m1pinN, LOW);
	analogWrite(m1pinS, pwm);
	
	digitalWrite(m2pinS, LOW);	
	analogWrite(m2pinN, turnPwm );  
	delay(1000);
}

void L293D::bckLeft()
{
	digitalWrite(m1pinS, LOW);
	analogWrite(m1pinN, pwm);
	
	digitalWrite(m2pinN, LOW);	
	analogWrite(m2pinS,turnPwm );     
	delay(1000);  
	
}

void L293D::bckRight()
{
	digitalWrite(m1pinS, LOW);
	analogWrite(m1pinN, turnPwm);
	
	digitalWrite(m2pinN, LOW);	
	analogWrite(m2pinS,pwm );     
	delay(1000);  
	
}

 
 
L293D::L293D(int x,int y, int m1n, int m1s,int m2n, int m2s)
 {
	this->pwm = x;
	this->turnPwm = y;
	this->m1pinN = m1n;
	this->m1pinS = m1s;
	this->m2pinN = m2n;
	this->m2pinS = m2s;
	pinMode(m1pinN,OUTPUT);
	pinMode(m1pinS,OUTPUT);
	pinMode(m2pinN,OUTPUT);
	pinMode(m2pinS,OUTPUT);
	digitalWrite(m1pinN,LOW);
	digitalWrite(m1pinS,LOW);
	digitalWrite(m2pinN,LOW);
	digitalWrite(m2pinS,LOW);
}